// Tencent is pleased to support the open source community by making ncnn available.
//
// Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
//
// Licensed under the BSD 3-Clause License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// https://opensource.org/licenses/BSD-3-Clause
//
// Unless required by applicable law or agreed to in writing, software distributed
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#ifndef NCNN_LAYER_SHADER_TYPE_H
#define NCNN_LAYER_SHADER_TYPE_H

namespace ncnn {

namespace LayerShaderType {
enum LayerShaderType
{
#include "layer_shader_type_enum.h"
};
} // namespace LayerShaderType

} // namespace ncnn

#endif // NCNN_LAYER_SHADER_TYPE_H
